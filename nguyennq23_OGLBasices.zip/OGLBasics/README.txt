Use the 1, 2, 3 keys to switch between Point, Line, and Surface materials respectively
